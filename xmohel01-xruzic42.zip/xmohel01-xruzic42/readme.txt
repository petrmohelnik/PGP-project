﻿PGP projekt

podzim 2015
Petr Mohelník, xmohel01
Tomáš Růžička, xruzic42

Zobrazování dýmu simulovaného pomocí částicového systému

Toto je pouze část archivu se zdrojovými soubory a dokumentací.
Úplnou verzi s knihovnami SDL, GLM a GLEW je možné stáhnout na adrese:
https://onedrive.live.com/redir?resid=38DC0D66740F9C7!18395&authkey=!ACKzJ3u70t0cfEM&ithint=file%2czip

Video je dostupné na adrese:
https://www.youtube.com/watch?v=XFKw5rXj8zE

Překlad je možný např. pomocí Visual Studia.
Ovládání:
kolečko myši - přiblížení
pravé tlačítko myši - otáčení